## Todo List

### Phase 1: Research and collect comprehensive Nigerian state and LGA data, and identify reliable sources for real-time land and material prices.
- [x] Research and compile a comprehensive list of all Nigerian states and their Local Government Areas (LGAs).
- [x] Identify reliable online sources for real-time land prices per LGA in Nigeria.
- [x] Identify reliable online sources for real-time polystyrene construction material prices (per panel/sqm) and traditional block prices in Nigeria.
- [x] Identify reliable online sources for unit prices of all construction items (nails, wire, water, etc.) in Nigeria.

### Phase 2: Develop backend services for LLM integration to fetch real-time land and material prices, and handle house plan analysis.
- [x] Set up a backend service (e.g., Flask) to handle LLM queries for real-time data.
- [x] Implement LLM integration for fetching land prices based on LGA.
- [x] Implement LLM integration for fetching polystyrene and traditional block prices.
- [x] Implement LLM integration for fetching detailed construction item prices.
- [x] Implement a service to handle house plan uploads and LLM-based analysis.

### Phase 3: Update frontend UI to include all Nigerian states and LGAs, new input fields for house plans, and enhanced display for detailed cost breakdowns.
- [x] Update the land cost dropdown to include all Nigerian states and their LGAs.
- [x] Update the house cost location dropdown to include all Nigerian LGAs.
- [x] Add an option for traditional block construction alongside polystyrene.
- [x] Add a file upload input for house plans.
- [x] Enhance the display for detailed itemized lists of construction materials and costs.
- [x] Modify the budget planning section to show what the available budget can build.

### Phase 4: Integrate LLM functionality for real-time data fetching and house plan analysis, and test all new features thoroughly.
- [x] Integrate frontend with the new backend services for real-time data.
- [x] Implement logic for house plan upload and display of LLM analysis results.
- [x] Test all new features thoroughly (land cost, house cost, budget planning, chat assistant).on with both polystyrene and traditional blocks, and real-time material prices.
- [ ] Test detailed itemized list generation.
- [ ] Test budget planning with house plan analysis.

### Phase 5: Deploy the updated application and deliver the new URL to the user.
- [x] Deploy the enhanced application with full backend integration.
- [x] Deliver the new URL to the user.