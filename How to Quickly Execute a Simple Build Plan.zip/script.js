// Nigerian House Cost Calculator - Enhanced Version
class NigerianHouseCalculator {
    constructor() {
        this.statesLgas = {};
        this.currentTab = 'land-cost';
        this.apiBaseUrl = window.location.hostname === 'localhost' ? 'http://localhost:5000/api' : '/api';
        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.loadStatesAndLgas();
        this.populateStateDropdowns();
    }

    setupEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });

        // State change listeners
        document.getElementById('land-state').addEventListener('change', (e) => {
            this.populateLgaDropdown('land-lga', e.target.value);
        });
        document.getElementById('house-state').addEventListener('change', (e) => {
            this.populateLgaDropdown('house-lga', e.target.value);
        });
        document.getElementById('budget-state').addEventListener('change', (e) => {
            this.populateLgaDropdown('budget-lga', e.target.value);
        });

        // Calculate buttons
        document.getElementById('calculate-land-cost').addEventListener('click', () => this.calculateLandCost());
        document.getElementById('calculate-house-cost').addEventListener('click', () => this.calculateHouseCost());
        document.getElementById('calculate-budget-plan').addEventListener('click', () => this.calculateBudgetPlan());

        // Chat functionality
        document.getElementById('send-chat').addEventListener('click', () => this.sendChatMessage());
        document.getElementById('chat-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendChatMessage();
        });

        // File upload
        document.getElementById('house-plan-upload').addEventListener('change', (e) => this.handleFileUpload(e));
        document.querySelector('.remove-file-btn').addEventListener('click', () => this.removeUploadedFile());
    }

    async loadStatesAndLgas() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/states-lgas`);
            const data = await response.json();
            if (data.success) {
                this.statesLgas = data.data;
            } else {
                console.error('Failed to load states and LGAs:', data.error);
                // Fallback to local data if API fails
                this.loadFallbackData();
            }
        } catch (error) {
            console.error('Error loading states and LGAs:', error);
            this.loadFallbackData();
        }
    }

    loadFallbackData() {
        // Fallback data in case API is not available
        this.statesLgas = {
            'Lagos': ['Agege', 'Ajeromi-Ifelodun', 'Alimosho', 'Amuwo-Odofin', 'Apapa', 'Badagry', 'Epe', 'Eti-Osa', 'Ibeju-Lekki', 'Ifako-Ijaiye', 'Ikeja', 'Ikorodu', 'Kosofe', 'Lagos Island', 'Lagos Mainland', 'Mushin', 'Ojo', 'Oshodi-Isolo', 'Shomolu', 'Surulere'],
            'Abuja': ['Abaji', 'Abuja Municipal', 'Bwari', 'Gwagwalada', 'Kuje', 'Kwali'],
            'Rivers': ['Abua/Odual', 'Ahoada East', 'Ahoada West', 'Akuku Toru', 'Andoni', 'Asari-Toru', 'Bonny', 'Degema', 'Eleme', 'Emuoha', 'Etche', 'Gokana', 'Ikwerre', 'Khana', 'Obio/Akpor', 'Ogba/Egbema/Ndoni', 'Ogu/Bolo', 'Okrika', 'Omuma', 'Opobo/Nkoro', 'Oyigbo', 'Port-Harcourt', 'Tai']
        };
    }

    populateStateDropdowns() {
        const stateSelects = ['land-state', 'house-state', 'budget-state'];
        const states = Object.keys(this.statesLgas).sort();

        stateSelects.forEach(selectId => {
            const select = document.getElementById(selectId);
            select.innerHTML = '<option value="">Select State</option>';
            states.forEach(state => {
                const option = document.createElement('option');
                option.value = state;
                option.textContent = state;
                select.appendChild(option);
            });
        });
    }

    populateLgaDropdown(lgaSelectId, state) {
        const lgaSelect = document.getElementById(lgaSelectId);
        lgaSelect.innerHTML = '<option value="">Select LGA</option>';
        lgaSelect.disabled = !state;

        if (state && this.statesLgas[state]) {
            this.statesLgas[state].forEach(lga => {
                const option = document.createElement('option');
                option.value = lga;
                option.textContent = lga;
                lgaSelect.appendChild(option);
            });
        }
    }

    switchTab(tabName) {
        // Update active tab button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update active tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');

        this.currentTab = tabName;
    }

    showLoading() {
        document.getElementById('loading-overlay').style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loading-overlay').style.display = 'none';
    }

    async calculateLandCost() {
        const state = document.getElementById('land-state').value;
        const lga = document.getElementById('land-lga').value;
        const size = parseInt(document.getElementById('land-size').value);

        if (!state || !lga || !size) {
            alert('Please fill in all fields');
            return;
        }

        this.showLoading();

        try {
            const response = await fetch(`${this.apiBaseUrl}/land-price`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    state: state,
                    lga: lga,
                    size_sqm: size
                })
            });

            const data = await response.json();
            this.hideLoading();

            if (data.success) {
                this.displayLandResults(data.data);
            } else {
                alert('Error calculating land cost: ' + data.error);
            }
        } catch (error) {
            this.hideLoading();
            console.error('Error:', error);
            alert('Failed to calculate land cost. Please try again.');
        }
    }

    displayLandResults(data) {
        const resultsContainer = document.getElementById('land-results');
        const resultsContent = resultsContainer.querySelector('.results-content');
        const resultsDate = resultsContainer.querySelector('.results-date');

        resultsDate.textContent = `Updated: ${data.date}`;

        resultsContent.innerHTML = `
            <div class="result-summary">
                <div class="result-item">
                    <span class="result-label">Location:</span>
                    <span class="result-value">${data.lga}, ${data.state}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Land Size:</span>
                    <span class="result-value">${data.size_sqm.toLocaleString()} sqm</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Price per sqm:</span>
                    <span class="result-value">₦${data.price_per_sqm.toLocaleString()}</span>
                </div>
                <div class="result-item total">
                    <span class="result-label">Total Land Cost:</span>
                    <span class="result-value">₦${data.total_cost.toLocaleString()}</span>
                </div>
            </div>
            <div class="price-range">
                <h4>Price Range</h4>
                <p>₦${data.price_range.min_total.toLocaleString()} - ₦${data.price_range.max_total.toLocaleString()}</p>
                <small>Source: ${data.source}</small>
            </div>
        `;

        resultsContainer.style.display = 'block';
    }

    async calculateHouseCost() {
        const houseType = document.getElementById('house-type').value;
        const state = document.getElementById('house-state').value;
        const lga = document.getElementById('house-lga').value;
        const constructionType = document.querySelector('input[name="construction-type"]:checked').value;

        if (!houseType || !state || !lga) {
            alert('Please fill in all fields');
            return;
        }

        this.showLoading();

        try {
            const response = await fetch(`${this.apiBaseUrl}/house-cost`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    house_type: houseType,
                    state: state,
                    lga: lga,
                    construction_type: constructionType
                })
            });

            const data = await response.json();
            this.hideLoading();

            if (data.success) {
                this.displayHouseResults(data.data);
            } else {
                alert('Error calculating house cost: ' + data.error);
            }
        } catch (error) {
            this.hideLoading();
            console.error('Error:', error);
            alert('Failed to calculate house cost. Please try again.');
        }
    }

    displayHouseResults(data) {
        const resultsContainer = document.getElementById('house-results');
        const resultsContent = resultsContainer.querySelector('.results-content');
        const resultsDate = resultsContainer.querySelector('.results-date');

        resultsDate.textContent = `Updated: ${data.date}`;

        const houseTypeDisplay = data.house_type.replace(/_/g, ' ').replace(/\\b\\w/g, l => l.toUpperCase());
        const constructionTypeDisplay = data.construction_type.charAt(0).toUpperCase() + data.construction_type.slice(1);

        resultsContent.innerHTML = `
            <div class="result-summary">
                <div class="result-item">
                    <span class="result-label">House Type:</span>
                    <span class="result-value">${houseTypeDisplay}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Construction Type:</span>
                    <span class="result-value">${constructionTypeDisplay}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Location:</span>
                    <span class="result-value">${data.lga}, ${data.state}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Floor Area:</span>
                    <span class="result-value">${data.area_sqm} sqm</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Cost per sqm:</span>
                    <span class="result-value">₦${data.cost_per_sqm.toLocaleString()}</span>
                </div>
            </div>
            <div class="cost-breakdown">
                <h4>Cost Breakdown</h4>
                <div class="breakdown-item">
                    <span>Foundation:</span>
                    <span>₦${data.cost_breakdown.foundation.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Walls & Structure:</span>
                    <span>₦${data.cost_breakdown.walls_structure.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Roofing:</span>
                    <span>₦${data.cost_breakdown.roofing.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Electrical & Plumbing:</span>
                    <span>₦${data.cost_breakdown.electrical_plumbing.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Finishing:</span>
                    <span>₦${data.cost_breakdown.finishing.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Labor:</span>
                    <span>₦${data.cost_breakdown.labor.toLocaleString()}</span>
                </div>
                <div class="breakdown-item subtotal">
                    <span>Subtotal:</span>
                    <span>₦${data.subtotal.toLocaleString()}</span>
                </div>
                <div class="breakdown-item">
                    <span>Contingency (10%):</span>
                    <span>₦${data.contingency_10_percent.toLocaleString()}</span>
                </div>
                <div class="breakdown-item total">
                    <span>Total Cost:</span>
                    <span>₦${data.total_cost.toLocaleString()}</span>
                </div>
            </div>
        `;

        resultsContainer.style.display = 'block';
    }

    async calculateBudgetPlan() {
        const availableBudget = parseInt(document.getElementById('available-budget').value);
        const monthlySavings = parseInt(document.getElementById('monthly-savings').value);
        const state = document.getElementById('budget-state').value;
        const lga = document.getElementById('budget-lga').value;

        if (!availableBudget || !state || !lga) {
            alert('Please fill in available budget, state, and LGA');
            return;
        }

        this.showLoading();

        try {
            const response = await fetch(`${this.apiBaseUrl}/budget-planning`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    available_budget: availableBudget,
                    monthly_savings: monthlySavings || 0,
                    state: state,
                    lga: lga
                })
            });

            const data = await response.json();
            this.hideLoading();

            if (data.success) {
                this.displayBudgetResults(data.data);
            } else {
                alert('Error calculating budget plan: ' + data.error);
            }
        } catch (error) {
            this.hideLoading();
            console.error('Error:', error);
            alert('Failed to calculate budget plan. Please try again.');
        }
    }

    displayBudgetResults(data) {
        const resultsContainer = document.getElementById('budget-results');
        const resultsContent = resultsContainer.querySelector('.results-content');
        const resultsDate = resultsContainer.querySelector('.results-date');

        resultsDate.textContent = `Updated: ${data.date}`;

        let recommendationsHtml = '';
        if (data.recommendations.length > 0) {
            recommendationsHtml = `
                <div class="recommendations">
                    <h4>What You Can Build</h4>
                    ${data.recommendations.map(rec => `
                        <div class="recommendation-item ${rec.status}">
                            <h5>${rec.house_type.replace(/_/g, ' ').replace(/\\b\\w/g, l => l.toUpperCase())}</h5>
                            <p>Total Cost: ₦${rec.total_cost.toLocaleString()}</p>
                            <p>Land: ₦${rec.land_cost.toLocaleString()} | House: ₦${rec.house_cost.toLocaleString()}</p>
                            ${rec.status === 'affordable_now' ? 
                                '<span class="status-badge affordable">Affordable Now!</span>' :
                                `<span class="status-badge save-required">Save for ${rec.months_to_save} months</span>`
                            }
                        </div>
                    `).join('')}
                </div>
            `;
        }

        let phasesHtml = '';
        if (data.construction_phases.length > 0) {
            phasesHtml = `
                <div class="construction-phases">
                    <h4>Construction Plan</h4>
                    ${data.construction_phases.map(phase => `
                        <div class="phase-item">
                            <div class="phase-header">
                                <span class="phase-name">${phase.phase}</span>
                                <span class="phase-cost">₦${phase.cost.toLocaleString()}</span>
                            </div>
                            <div class="phase-details">
                                <span class="phase-status ${phase.status}">${phase.status.replace('_', ' ')}</span>
                                ${phase.months_to_save > 0 ? 
                                    `<span class="phase-timeline">Save for ${phase.months_to_save} months</span>` : 
                                    ''
                                }
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        resultsContent.innerHTML = `
            <div class="result-summary">
                <div class="result-item">
                    <span class="result-label">Available Budget:</span>
                    <span class="result-value">₦${data.available_budget.toLocaleString()}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Monthly Savings:</span>
                    <span class="result-value">₦${data.monthly_savings.toLocaleString()}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Location:</span>
                    <span class="result-value">${data.lga}, ${data.state}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Land Price (per sqm):</span>
                    <span class="result-value">₦${data.land_price_per_sqm.toLocaleString()}</span>
                </div>
            </div>
            ${recommendationsHtml}
            ${phasesHtml}
        `;

        resultsContainer.style.display = 'block';
    }

    sendChatMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();

        if (!message) return;

        this.addChatMessage(message, 'user');
        input.value = '';

        // Simulate AI response
        setTimeout(() => {
            const response = this.generateChatResponse(message);
            this.addChatMessage(response, 'bot');
        }, 1000);
    }

    addChatMessage(message, sender) {
        const chatMessages = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas ${sender === 'user' ? 'fa-user' : 'fa-robot'}"></i>
            </div>
            <div class="message-content">
                <p>${message}</p>
            </div>
        `;

        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    generateChatResponse(message) {
        const lowerMessage = message.toLowerCase();

        if (lowerMessage.includes('polystyrene') || lowerMessage.includes('eps')) {
            return `Polystyrene construction is 25% cheaper than traditional blocks and offers excellent insulation. Current prices range from ₦8,000-₦12,000 per sqm including installation. It's perfect for Nigeria's climate as it keeps buildings cool and reduces energy costs.`;
        } else if (lowerMessage.includes('cost') || lowerMessage.includes('price')) {
            return `Building costs vary by location and materials. In Lagos, expect ₦50,000-₦80,000 per sqm for polystyrene construction. Use our calculator above for accurate estimates based on your specific location and house type.`;
        } else if (lowerMessage.includes('land')) {
            return `Land prices vary significantly across Nigeria. Lagos ranges from ₦150,000-₦1,000,000 per sqm depending on the LGA. Use our land cost calculator for current prices in your preferred location.`;
        } else if (lowerMessage.includes('how') || lowerMessage.includes('wetin')) {
            return `To build your house: 1) Buy land with proper documentation, 2) Get building approval, 3) Start with foundation, 4) Build walls (polystyrene recommended), 5) Install roofing, 6) Do electrical/plumbing, 7) Finish with tiles and paint. Budget 10% extra for contingencies.`;
        } else {
            return `I can help you with construction costs, material prices, building processes, and polystyrene construction guidance. Ask me specific questions about your building project!`;
        }
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Validate file type and size
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
        const maxSize = 10 * 1024 * 1024; // 10MB

        if (!allowedTypes.includes(file.type)) {
            alert('Please upload a PDF, JPG, or PNG file.');
            event.target.value = '';
            return;
        }

        if (file.size > maxSize) {
            alert('File size must be less than 10MB.');
            event.target.value = '';
            return;
        }

        // Show uploaded file info
        const fileInfo = document.getElementById('uploaded-file-info');
        const fileName = fileInfo.querySelector('.file-name');
        fileName.textContent = file.name;
        fileInfo.style.display = 'flex';

        // Hide the upload label
        document.querySelector('.file-upload-label').style.display = 'none';
    }

    removeUploadedFile() {
        document.getElementById('house-plan-upload').value = '';
        document.getElementById('uploaded-file-info').style.display = 'none';
        document.querySelector('.file-upload-label').style.display = 'flex';
    }
}

// Initialize the calculator when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new NigerianHouseCalculator();
});

