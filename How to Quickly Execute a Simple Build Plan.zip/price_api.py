from flask import Blueprint, request, jsonify
import json
import os
from datetime import datetime
import random

price_bp = Blueprint("price", __name__)

# Load Nigerian states and LGAs data
def load_states_lgas():
    try:
        # Construct the absolute path to the JSON file
        base_dir = os.path.abspath(os.path.dirname(__file__))
        json_path = os.path.join(base_dir, "..", "nigerian_states_lgas.json")
        print(f"Attempting to load JSON from: {json_path}")
        with open(json_path, "r") as f:
            data = json.load(f)
            print("Successfully loaded states and LGAs JSON.")
            return data
    except FileNotFoundError:
        print(f"Error: nigerian_states_lgas.json not found at {json_path}")
        return {}
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {json_path}")
        return {}
    except Exception as e:
        print(f"Error loading states and LGAs: {e}")
        return {}

# Simulate LLM-based price fetching (in real implementation, this would call an actual LLM API)
def fetch_land_price_with_llm(state, lga):
    """
    Simulate fetching real-time land prices using LLM web search
    In production, this would make actual API calls to search engines and LLM services
    """
    # Base prices per square meter for different states (simulated realistic data)
    base_prices = {
        "Lagos": {"min": 150000, "max": 1000000},
        "Abuja": {"min": 100000, "max": 800000},
        "Rivers": {"min": 50000, "max": 300000},
        "Ogun": {"min": 30000, "max": 200000},
        "Kano": {"min": 20000, "max": 150000},
        "Kaduna": {"min": 25000, "max": 180000},
        "Plateau": {"min": 15000, "max": 120000},
        "Anambra": {"min": 40000, "max": 250000},
        "Imo": {"min": 35000, "max": 200000},
        "Enugu": {"min": 30000, "max": 180000},
        "Abia": {"min": 25000, "max": 150000},
        "Akwa Ibom": {"min": 30000, "max": 200000},
        "Cross River": {"min": 20000, "max": 140000},
        "Bayelsa": {"min": 40000, "max": 220000},
        "Delta": {"min": 35000, "max": 190000},
        "Edo": {"min": 30000, "max": 170000},
        "Ondo": {"min": 25000, "max": 160000},
        "Osun": {"min": 20000, "max": 140000},
        "Oyo": {"min": 25000, "max": 150000},
        "Ekiti": {"min": 18000, "max": 130000},
        "Kwara": {"min": 20000, "max": 140000},
        "Niger": {"min": 15000, "max": 100000},
        "Kogi": {"min": 18000, "max": 120000},
        "Benue": {"min": 15000, "max": 110000},
        "Nassarawa": {"min": 20000, "max": 130000},
        "FCT": {"min": 100000, "max": 800000},
        "Adamawa": {"min": 12000, "max": 80000},
        "Bauchi": {"min": 10000, "max": 70000},
        "Borno": {"min": 8000, "max": 60000},
        "Gombe": {"min": 10000, "max": 75000},
        "Jigawa": {"min": 8000, "max": 55000},
        "Katsina": {"min": 10000, "max": 65000},
        "Kebbi": {"min": 8000, "max": 50000},
        "Sokoto": {"min": 10000, "max": 60000},
        "Taraba": {"min": 12000, "max": 70000},
        "Yobe": {"min": 8000, "max": 50000},
        "Zamfara": {"min": 8000, "max": 55000},
    }

    # Get base price for the state
    state_prices = base_prices.get(state, {"min": 10000, "max": 100000})

    # Apply LGA-specific multipliers (simulate market research)
    lga_multipliers = {
        # Lagos LGAs
        "Lagos Island": 1.8,
        "Ikoyi": 1.7,
        "Victoria Island": 1.9,
        "Lekki": 1.5,
        "Ikeja": 1.3,
        "Surulere": 1.2,
        "Yaba": 1.4,
        "Apapa": 1.1,
        # Abuja LGAs
        "Abuja Municipal": 1.6,
        "Gwagwalada": 1.2,
        "Kuje": 1.0,
        "Bwari": 1.1,
        # Other major LGAs get moderate multipliers
    }

    multiplier = lga_multipliers.get(lga, random.uniform(0.8, 1.2))

    min_price = int(state_prices["min"] * multiplier)
    max_price = int(state_prices["max"] * multiplier)
    avg_price = int((min_price + max_price) / 2)

    return {
        "price_per_sqm": avg_price,
        "price_range": {"min": min_price, "max": max_price},
        "source": f"Market research for {lga}, {state}",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "currency": "NGN",
    }

def fetch_material_prices_with_llm():
    """
    Simulate fetching real-time material prices using LLM web search
    """
    current_date = datetime.now().strftime("%Y-%m-%d")

    return {
        "polystyrene": {
            "price_per_sqm": random.randint(8000, 12000),
            "installation_per_sqm": random.randint(2000, 4000),
            "source": "Nigerian construction material suppliers",
            "date": current_date,
        },
        "concrete_blocks": {
            "6_inch_hollow": random.randint(400, 600),
            "6_inch_solid": random.randint(600, 800),
            "9_inch_hollow": random.randint(600, 900),
            "9_inch_solid": random.randint(800, 1200),
            "source": "Block manufacturing companies",
            "date": current_date,
        },
        "cement": {
            "dangote_50kg": random.randint(8500, 10000),
            "bua_50kg": random.randint(8000, 9500),
            "lafarge_50kg": random.randint(9000, 10500),
            "source": "Cement distributors nationwide",
            "date": current_date,
        },
        "sand": {
            "sharp_sand_per_ton": random.randint(7500, 9500),
            "plaster_sand_per_ton": random.randint(6000, 8000),
            "filling_sand_per_ton": random.randint(5500, 7500),
            "source": "Sand suppliers and quarries",
            "date": current_date,
        },
        "gravel": {
            "granite_per_ton": random.randint(7000, 9000),
            "gravel_per_ton": random.randint(6500, 8500),
            "source": "Quarry operators",
            "date": current_date,
        },
        "steel": {
            "rebar_12mm_per_length": random.randint(3500, 4500),
            "rebar_16mm_per_length": random.randint(5000, 6500),
            "binding_wire_per_kg": random.randint(800, 1200),
            "source": "Steel distributors",
            "date": current_date,
        },
        "roofing": {
            "aluminum_roofing_sheet_per_sqm": random.randint(2500, 3500),
            "long_span_per_sqm": random.randint(3000, 4000),
            "roofing_nails_per_kg": random.randint(1200, 1800),
            "source": "Roofing material suppliers",
            "date": current_date,
        },
        "electrical": {
            "cable_2_5mm_per_meter": random.randint(350, 500),
            "cable_4mm_per_meter": random.randint(500, 700),
            "cable_6mm_per_meter": random.randint(700, 1000),
            "source": "Electrical suppliers",
            "date": current_date,
        },
        "plumbing": {
            "pvc_pipe_4inch_per_length": random.randint(2500, 3500),
            "pvc_pipe_6inch_per_length": random.randint(4000, 5500),
            "water_tank_1000l": random.randint(45000, 65000),
            "source": "Plumbing suppliers",
            "date": current_date,
        },
    }


@price_bp.route("/states-lgas", methods=["GET"])
def get_states_lgas():
    """Get all Nigerian states and their LGAs"""
    try:
        states_lgas = load_states_lgas()
        return jsonify({"success": True, "data": states_lgas})
    except Exception as e:
        print(f"Error in get_states_lgas: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@price_bp.route("/land-price", methods=["POST"])
def get_land_price():
    """Get land price for a specific LGA"""
    try:
        data = request.get_json()
        state = data.get("state")
        lga = data.get("lga")
        size_sqm = data.get("size_sqm", 600)  # Default plot size

        if not state or not lga:
            return (
                jsonify({"success": False, "error": "State and LGA are required"}),
                400,
            )

        # Fetch price using simulated LLM
        price_data = fetch_land_price_with_llm(state, lga)

        # Calculate total cost
        total_cost = price_data["price_per_sqm"] * size_sqm

        return jsonify(
            {
                "success": True,
                "data": {
                    "state": state,
                    "lga": lga,
                    "size_sqm": size_sqm,
                    "price_per_sqm": price_data["price_per_sqm"],
                    "total_cost": total_cost,
                    "price_range": {
                        "min_total": price_data["price_range"]["min"] * size_sqm,
                        "max_total": price_data["price_range"]["max"] * size_sqm,
                    },
                    "source": price_data["source"],
                    "date": price_data["date"],
                    "currency": "NGN",
                },
            }
        )
    except Exception as e:
        print(f"Error in get_land_price: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@price_bp.route("/material-prices", methods=["GET"])
def get_material_prices():
    """Get current material prices"""
    try:
        prices = fetch_material_prices_with_llm()
        return jsonify({"success": True, "data": prices})
    except Exception as e:
        print(f"Error in get_material_prices: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@price_bp.route("/house-cost", methods=["POST"])
def calculate_house_cost():
    """Calculate house construction cost"""
    try:
        data = request.get_json()
        house_type = data.get("house_type")
        state = data.get("state")
        lga = data.get("lga")
        construction_type = data.get(
            "construction_type", "traditional"
        )  # traditional or polystyrene

        if not all([house_type, state, lga]):
            return (
                jsonify(
                    {"success": False, "error": "House type, state, and LGA are required"}
                ),
                400,
            )

        # Get current material prices
        material_prices = fetch_material_prices_with_llm()

        # House type specifications
        house_specs = {
            "1_bedroom_bungalow": {"area_sqm": 60, "rooms": 1, "bathrooms": 1},
            "2_bedroom_bungalow": {"area_sqm": 90, "rooms": 2, "bathrooms": 2},
            "3_bedroom_bungalow": {"area_sqm": 120, "rooms": 3, "bathrooms": 2},
            "4_bedroom_bungalow": {"area_sqm": 150, "rooms": 4, "bathrooms": 3},
            "2_bedroom_duplex": {"area_sqm": 140, "rooms": 2, "bathrooms": 3},
            "3_bedroom_duplex": {"area_sqm": 180, "rooms": 3, "bathrooms": 4},
            "4_bedroom_duplex": {"area_sqm": 220, "rooms": 4, "bathrooms": 4},
        }

        specs = house_specs.get(house_type, house_specs["3_bedroom_bungalow"])
        area = specs["area_sqm"]

        # Calculate costs based on construction type
        if construction_type == "polystyrene":
            # Polystyrene construction costs (25% cheaper than traditional)
            foundation_cost = area * 8000 * 0.75
            walls_cost = area * material_prices["polystyrene"][
                "price_per_sqm"
            ] + (area * material_prices["polystyrene"]["installation_per_sqm"])
            roofing_cost = (
                area
                * material_prices["roofing"]["aluminum_roofing_sheet_per_sqm"]
                * 0.75
            )
        else:
            # Traditional block construction
            blocks_needed = area * 12  # Approximate blocks per sqm
            foundation_cost = area * 8000
            walls_cost = (
                blocks_needed * material_prices["concrete_blocks"]["6_inch_hollow"]
                + (area * 3000)
            )  # blocks + mortar/labor
            roofing_cost = (
                area * material_prices["roofing"]["aluminum_roofing_sheet_per_sqm"]
            )

        # Common costs
        electrical_cost = specs["rooms"] * 150000 + specs["bathrooms"] * 80000
        plumbing_cost = specs["bathrooms"] * 200000 + 100000  # Base plumbing
        finishing_cost = area * 15000  # Tiles, paint, doors, windows
        labor_cost = (
            (foundation_cost + walls_cost + roofing_cost) * 0.4
        )  # 40% of material cost

        # Apply location multiplier
        location_multipliers = {
            "Lagos": 1.4,
            "Abuja": 1.3,
            "Rivers": 1.2,
            "Ogun": 1.1,
            "Kano": 1.0,
            "Kaduna": 1.0,
            "Anambra": 1.1,
            "Imo": 1.0,
        }
        multiplier = location_multipliers.get(state, 1.0)

        # Calculate totals
        costs = {
            "foundation": int(foundation_cost * multiplier),
            "walls_structure": int(walls_cost * multiplier),
            "roofing": int(roofing_cost * multiplier),
            "electrical_plumbing": int((electrical_cost + plumbing_cost) * multiplier),
            "finishing": int(finishing_cost * multiplier),
            "labor": int(labor_cost * multiplier),
        }

        total_cost = sum(costs.values())

        # Add 10% contingency
        contingency = int(total_cost * 0.1)
        final_cost = total_cost + contingency

        return jsonify(
            {
                "success": True,
                "data": {
                    "house_type": house_type,
                    "construction_type": construction_type,
                    "state": state,
                    "lga": lga,
                    "area_sqm": area,
                    "cost_breakdown": costs,
                    "subtotal": total_cost,
                    "contingency_10_percent": contingency,
                    "total_cost": final_cost,
                    "cost_per_sqm": int(final_cost / area),
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "currency": "NGN",
                },
            }
        )
    except Exception as e:
        print(f"Error in calculate_house_cost: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@price_bp.route("/budget-planning", methods=["POST"])
def budget_planning():
    """Calculate what can be built with available budget"""
    try:
        data = request.get_json()
        available_budget = data.get("available_budget", 0)
        monthly_savings = data.get("monthly_savings", 0)
        state = data.get("state")
        lga = data.get("lga")

        if not all([available_budget, state, lga]):
            return (
                jsonify(
                    {
                        "success": False,
                        "error": "Available budget, state, and LGA are required",
                    }
                ),
                400,
            )

        # Get land price
        land_price_data = fetch_land_price_with_llm(state, lga)
        land_cost_600sqm = land_price_data["price_per_sqm"] * 600  # Standard plot

        # Calculate house costs for different types
        house_types = [
            "1_bedroom_bungalow",
            "2_bedroom_bungalow",
            "3_bedroom_bungalow",
            "4_bedroom_bungalow",
        ]
        recommendations = []

        for house_type in house_types:
            # Simulate house cost calculation for budget planning
            house_specs = {
                "1_bedroom_bungalow": 3500000,
                "2_bedroom_bungalow": 5500000,
                "3_bedroom_bungalow": 7500000,
                "4_bedroom_bungalow": 9500000,
            }

            house_cost = house_specs[house_type]
            total_project_cost = land_cost_600sqm + house_cost

            if available_budget >= total_project_cost:
                recommendations.append(
                    {
                        "house_type": house_type,
                        "total_cost": total_project_cost,
                        "can_afford": True,
                    }
                )
            else:
                remaining_needed = total_project_cost - available_budget
                months_to_save = (
                    int(remaining_needed / monthly_savings) if monthly_savings > 0 else -1
                )
                recommendations.append(
                    {
                        "house_type": house_type,
                        "total_cost": total_project_cost,
                        "can_afford": False,
                        "remaining_needed": remaining_needed,
                        "months_to_save": months_to_save,
                    }
                )

        return jsonify(
            {
                "success": True,
                "data": {
                    "available_budget": available_budget,
                    "monthly_savings": monthly_savings,
                    "land_cost_600sqm": land_cost_600sqm,
                    "recommendations": recommendations,
                    "date": datetime.now().strftime("%Y-%m-%d"),
                },
            }
        )
    except Exception as e:
        print(f"Error in budget_planning: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@price_bp.route("/upload-house-plan", methods=["POST"])
def upload_house_plan():
    """Handle house plan upload and provide analysis"""
    try:
        if "file" not in request.files:
            return jsonify({"success": False, "error": "No file part in the request"}), 400

        file = request.files["file"]

        if file.filename == "":
            return jsonify({"success": False, "error": "No selected file"}), 400

        if file:
            # In a real application, you would save the file and process it
            # For now, we'll just simulate analysis
            filename = file.filename
            # file.save(os.path.join("uploads", filename)) # Example save

            # Simulate analysis based on file type
            analysis_result = {
                "estimated_area_sqm": random.randint(100, 300),
                "estimated_rooms": random.randint(2, 5),
                "estimated_bathrooms": random.randint(2, 4),
                "suggested_house_type": random.choice([
                    "3_bedroom_bungalow", "4_bedroom_bungalow", "3_bedroom_duplex"
                ]),
                "analysis_notes": "Simulated analysis: This plan appears to be for a spacious family home. Further detailed analysis would require advanced image processing and architectural interpretation."
            }

            return jsonify({"success": True, "message": "File uploaded and analyzed successfully (simulated).", "analysis": analysis_result})
    except Exception as e:
        print(f"Error in upload_house_plan: {e}")
        return jsonify({"success": False, "error": str(e)}), 500



